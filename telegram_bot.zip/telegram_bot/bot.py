import os
from telegram import Update, ChatJoinRequest
from telegram.ext import ApplicationBuilder, ChatJoinRequestHandler, ContextTypes

BOT_TOKEN = os.getenv("BOT_TOKEN")
VIDEO_ID = os.getenv("VIDEO_ID")

WELCOME_TEXT = """
SALOM SALOM QARINDOOSHIM 👋

📢 2 kunlik BEPUL darslikda nimalar o‘rgatiladi?

1️⃣ 🇨🇳Xitoyning Ichki va tashqi marketplace ning farqi
2️⃣ Pinduoduo (ichki marketplace) dan to’g’ri ro‘yxatdan o‘tish tartibi
3️⃣ Kargo turlari – avto va avia kargoning farqi
4️⃣ Xitoyning Yuannini so‘mga hisoblash usuli

🟡 ESLATMA:
Bu — Xitoydan tovar zakaz qilish bo‘yicha 30 KUNLIK to‘liq darslikning atigi 2 KUNIgina!

📌 DARSLARIMIZ  sizga yoqsa, qolgan darslarni pul to’lab davom  ettirishingiz mumkin.

✅ DARSLAR 23-24 AVGUST KUNLARI  AYNAN MANASHU 👇

👉 https://t.me/+_Xpi9AEla5hkNjhi 👈 YOPIQ  KANALDA  BÒLIB ÒTADI
"""

async def handle_join_request(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        await update.chat_join_request.approve()
        await context.bot.send_video(
            chat_id=update.chat_join_request.from_user.id,
            video=VIDEO_ID,
            caption=WELCOME_TEXT
        )
    except Exception as e:
        print("Error:", e)

if __name__ == '__main__':
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(ChatJoinRequestHandler(handle_join_request))
    print("Bot started...")
    app.run_polling()